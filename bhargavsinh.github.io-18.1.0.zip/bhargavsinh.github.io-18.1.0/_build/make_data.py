"""One-off: derive data/*.json from the existing page fragments so every string is verbatim site text.
After this runs once, the JSON files are the editable source of truth for the hub pages (about/projects/publications/research/contact)."""
import os, re, json
from bs4 import BeautifulSoup
H = os.path.dirname(os.path.abspath(__file__))
def frag(n): return BeautifulSoup(open(os.path.join(H, 'content', n + '.html'), encoding='utf8').read(), 'lxml')
def t(e): return re.sub(r'\s+', ' ', e.get_text(' ', strip=True)).strip()
def tt(e):  # text with sane punctuation spacing
    return re.sub(r'\s+([,.;:!?])', r'\1', t(e))

vis, about, resume = frag('Visitor__Visitindex'), frag('Visitor__about'), frag('HR-Recruiter__resume')
bp, hr, blog, other = frag('Book-Publications-Reader__BPindex'), frag('HR-Recruiter__HRRindex'), frag('Visitor__blog'), frag('Book-Publications-Reader__otherlinks')

def cards(soup):
    out = {}
    for c in soup.select('.card'):
        h = c.find('h3'); a = c.select_one('a')
        out[tt(h)] = dict(kind=tt(c.select_one('.eyebrow')), title=tt(h), desc=tt(c.find('p')), href=a['href'], cta=tt(c.select_one('.card-link')) if c.select_one('.card-link') else '')
    return out
V, B, HR = cards(vis), cards(bp), cards(hr)

def strip_n(x): return re.sub(r'^\d+\.\s*', '', x)
def sect(i):
    return about.find(id=i)
def first_p(i): return tt(sect(i).find('p'))

# ---- profile
lead = tt(vis.select_one('.hero > p'))
paras = [tt(p) for p in resume.select('p')]
profile = dict(
    name='Bhargavsinh Sisodiya', tagline='Heritage in Memory. Knowledge in Creation.',
    lead=lead, headline=paras[0], summary=paras[1],
    links=[dict(label='Email', text='bhargavsinh.bca@gmail.com', href='mailto:bhargavsinh.bca@gmail.com'),
           dict(label='GitHub', text='github.com/bhargavsinh', href='https://github.com/bhargavsinh'),
           dict(label='LinkedIn', text='Linkedin Profile', href='https://www.linkedin.com/in/bhargavsinh-sisodiya-789507373'),
           dict(label='Pratilipi', text='Pratilipi Profile', href='https://pratilipi.app.link/KzxCu1QGv6b'),
           dict(label='Instagram', text='Instagram', href='https://instagram.com/bs_pushtisoul'),
           dict(label='Pushti Sahitya', text='pushtisahitya.org', href='https://pushtisahitya.org/')],
    contact_note=[tt(p) for p in sect('contact').find_all('p')][-1],
    about=[dict(label=l, id=i, text=first_p(i), heading=strip_n(tt(sect(i).find('h2')))) for l, i in [
        ('Personal Profile', 'identity'), ('Academic Background', 'education'), ('Technical Interests', 'technology'),
        ('Literary Contributions', 'writing'), ('Research Interests', 'archives'), ('Heritage & Institutional Context', 'heritage')]],
    institution=dict(title='Anand Vihar Bhavan', tag=V['Anand Vihar Bhavan']['desc'], text=first_p('anand-vihar'), href='Visitor/ananadviharbhavan.html'),
)

# ---- projects (about § "Independent Projects & Experiments" — verbatim; other fields intentionally null until approved)
proj = []
sec = sect('creative-projects')
for h in sec.find_all('h3'):
    p = h.find_next_sibling('p')
    proj.append(dict(name=tt(h), description=tt(p), category=None, stack=None, status=None, live=None, source=None, links=[], featured=False,
                     more='Visitor/about.html#creative-projects'))
byname = {p['name']: p for p in proj}
byname['Personal Portfolio']['links'] = [dict(label='bhargavsinh.github.io', href='index.html'), dict(label='github.com/bhargavsinh', href='https://github.com/bhargavsinh')]
byname['Digital Genealogy']['links'] = [dict(label='Explore the genealogy page', href='Visitor/vanshavali.html')]
for n in ('Personal Portfolio', 'SDSP', 'BharBlock'): byname[n]['featured'] = True
projects = dict(_fields='category, stack, status, live, source are null until approved content exists; the page shows only fields that are filled.', items=proj, note=tt(sec.find_all('p')[-1]),
                work=dict(kind=HR['Projects']['kind'], title='Projects', desc=HR['Projects']['desc'], href='HR-Recruiter/projects.html'),
                tool=dict(kind=HR['pwriter']['kind'], title='pwriter', desc=HR['pwriter']['desc'], href='HR-Recruiter/pwriter.html'))

# ---- publications (otherlinks rows) + covers/platform links from the book pages
cover = {'mahabharat-rajdharma.html': 'assets/images/books/book-mahabharat-rajdharma-cover.webp', 'satyanisodh.html': 'assets/images/books/book-satyanisodh-cover.webp', 'astitva-garima.html': 'assets/images/books/book-astitva-garima-cover.webp'}
def play(f):
    if not os.path.exists(os.path.join(H, 'content', 'Book-Publications-Reader__' + f.replace('.html', '') + '.html')): return None
    s = frag('Book-Publications-Reader__' + f.replace('.html', ''))
    a = [x['href'] for x in s.select('a[href^="https://play.google.com/store/books"]')]
    return a[0] if a else None
pubs = []
for tbl_i, group in ((0, 'Books'), (1, 'Other Publications')):
    tbl = other.select('table')[tbl_i]
    for tr in tbl.select('tbody tr'):
        td = tr.find_all('td'); strong = td[1].find('strong'); sub = td[1].find('span')
        href = td[5].find('a')['href']; f = href.split('/')[-1]
        pubs.append(dict(group=group, title=tt(strong), subtitle=tt(sub), author='Bhargavsinh Sisodiya', language=tt(td[2]), category=tt(td[3]), status=tt(td[4]),
                         href=href if href.startswith('..') is False else href.replace('../', ''), cta=tt(td[5].find('a')), cover=cover.get(f), platform=('Google Play Books' if play(f) else None), platform_href=play(f), date=None))
for p in pubs:  # portal-relative → root-relative
    if not p['href'].startswith(('Visitor/', 'http')) and not p['href'].startswith('..'): p['href'] = 'Book-Publications-Reader/' + p['href']
publications = dict(items=pubs, note=[tt(x) for x in other.select('.kicker')][-1])

# ---- research & heritage
research = [
    dict(title='Vanshavali', kind=V['Vanshavali']['kind'], desc=V['Vanshavali']['desc'], date=tt(frag('Visitor__vanshavali').select_one('.chip')), status='Published', source='Visitor portal', href='Visitor/vanshavali.html', cta=V['Vanshavali']['cta']),
    dict(title=V['Mewad History']['title'], kind=V['Mewad History']['kind'], desc=V['Mewad History']['desc'], date=tt(frag('Visitor__Mewad_history_blog').select_one('.chip')), status=None, source='Visitor portal', href='Visitor/Mewad_history_blog.html', cta=V['Mewad History']['cta']),
    dict(title=V['Pushtimarg Literature']['title'], kind=V['Pushtimarg Literature']['kind'], desc=V['Pushtimarg Literature']['desc'], date=None, status=None, source='Books & Publications portal', href='Book-Publications-Reader/pushtimarg.html', cta=V['Pushtimarg Literature']['cta']),
    dict(title=V['પુષ્ટિમાર્ગ માં ગૃહ સેવા']['title'], kind=V['પુષ્ટિમાર્ગ માં ગૃહ સેવા']['kind'], desc=V['પુષ્ટિમાર્ગ માં ગૃહ સેવા']['desc'], date='30 Dec 2025 • સંશોધિત: ઓગસ્ટ 2026', status=None, source='Visitor portal', href='Book-Publications-Reader/pushtimarg-ma-gruh-seva.html', cta=V['પુષ્ટિમાર્ગ માં ગૃહ સેવા']['cta']),
    dict(title='Anand Vihar Bhavan', kind=V['Anand Vihar Bhavan']['kind'], desc=V['Anand Vihar Bhavan']['desc'], date=None, status=None, source='Visitor portal', href='Visitor/ananadviharbhavan.html', cta=V['Anand Vihar Bhavan']['cta']),
    dict(title=strip_n(tt(sect('archives').find('h2'))), kind='Digital Archives', desc=first_p('archives'), date=None, status=None, source='About', href='Visitor/about.html#archives', cta='Read more'),
]
rt = json.load(open(os.path.join(H, 'content', '_meta.json'), encoding='utf8')) if False else None
D = os.path.join(H, 'data'); os.makedirs(D, exist_ok=True)
for n, o in (('profile', profile), ('projects', projects), ('publications', publications), ('research', dict(items=research))):
    json.dump(o, open(os.path.join(D, n + '.json'), 'w', encoding='utf8'), ensure_ascii=False, indent=1)
print('ok'); print(json.dumps(dict(profile=dict(lead=lead, headline=paras[0], summary=paras[1][:80], inst=profile['institution']), pubs=[(p['title'][:25], p['href'], p['status']) for p in pubs], proj=[(p['name'], p['description'][:40]) for p in proj], note=projects['note'], rs=[(r['title'], r['kind'], r['date']) for r in research]), ensure_ascii=False, indent=1))
