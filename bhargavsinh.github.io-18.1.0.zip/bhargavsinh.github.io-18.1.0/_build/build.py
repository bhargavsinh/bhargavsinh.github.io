#!/usr/bin/env python3
"""Static site generator for bhargavsinh.github.io (V18).

    python3 _build/build.py            # writes the finished site into ./ (repo root), one level above _build/

Inputs : _build/content/*.html  (page bodies, verbatim text)  +  _build/content/_meta.json  (titles / descriptions / JSON-LD)
         _build/assets/**        (css, js, images)             +  _build/legacy.json        (old root URL -> new URL redirects)
Outputs: every .html page, sw.js, manifest.json, sitemap.xml, robots.txt, assets/search-index.json
Requires: Python 3.9+, beautifulsoup4, lxml
"""
import os, re, json, shutil, sys, html, datetime
from bs4 import BeautifulSoup

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(HERE)
SITE = 'https://bhargavsinh.github.io'
VERSION = '18.1.0'
TODAY = '2026-11-06'
DATA = {n: json.load(open(os.path.join(HERE, 'data', n + '.json'), encoding='utf8')) for n in ('profile', 'projects', 'publications', 'research')}
LASTMOD = json.load(open(os.path.join(HERE, 'lastmod.json'), encoding='utf8'))
GLOBAL = [('Home', 'index.html', 'home'), ('About', 'about/', 'about'), ('Projects', 'projects/', 'projects'),
          ('Publications', 'publications/', 'publications'), ('Research', 'research/', 'research'), ('Contact', 'contact/', 'contact')]
SECT = {'Visitor/about.html': 'about', 'Visitor/blog.html': 'research', 'Visitor/Mewad_history_blog.html': 'research', 'Visitor/vanshavali.html': 'research',
        'Visitor/ananadviharbhavan.html': 'research', 'Visitor/contact.html': 'contact', 'HR-Recruiter/resume.html': 'about', 'HR-Recruiter/projects.html': 'projects',
        'HR-Recruiter/pwriter.html': 'projects', 'Book-Publications-Reader/BPindex.html': 'publications', 'Book-Publications-Reader/otherlinks.html': 'publications',
        'Book-Publications-Reader/satyanisodh.html': 'publications', 'Book-Publications-Reader/astitva-garima.html': 'publications',
        'Book-Publications-Reader/mahabharat-rajdharma.html': 'publications', 'Book-Publications-Reader/bookreadingpolicy.html': 'publications',
        'Book-Publications-Reader/pushtimarg.html': 'research', 'Book-Publications-Reader/pushtimarg-ma-gruh-seva.html': 'research'}
TAGLINE = 'Heritage in Memory. Knowledge in Creation.'
NAME = 'BHARGAVSINH SISODIYA'

meta = json.load(open(os.path.join(HERE, 'content', '_meta.json'), encoding='utf8'))
legacy = json.load(open(os.path.join(HERE, 'legacy.json'), encoding='utf8'))

# ------------------------------------------------------------------ site map
PORTALS = {
    'visitor': dict(dir='Visitor', label='Visitor', home='Visitindex.html',
                    nav=[('Home', 'Visitindex.html', 'home'), ('About', 'about.html', 'about'), ('Blogs', 'blog.html', 'blog'),
                         ('Genealogy', 'vanshavali.html', 'gen'), ('Anand Vihar', 'ananadviharbhavan.html', 'heritage'), ('Contact', 'contact.html', 'contact')]),
    'hr': dict(dir='HR-Recruiter', label='HR Recruiter', home='HRRindex.html',
               nav=[('Home', 'HRRindex.html', 'home'), ('Resume', 'resume.html', 'resume'), ('Projects', 'projects.html', 'projects'),
                    ('pwriter', 'pwriter.html', 'pwriter'), ('Ghostwriting', 'ghostwriting.html', 'ghost'), ('Contact', '../Visitor/contact.html', 'contact')]),
    'books': dict(dir='Book-Publications-Reader', label='Books & Publications', home='BPindex.html',
                  nav=[('Home', 'BPindex.html', 'home'), ('Publications', 'otherlinks.html', 'pub'), ('Pushtimarg', 'pushtimarg.html', 'pushti'),
                       ('Reading policy', 'bookreadingpolicy.html', 'policy'), ('About the author', '../Visitor/about.html', 'about')]),
}
# (portal, file, short label, nav key, main lang, protect, group)
P = [
    ('visitor', 'Visitindex.html', 'Home', 'home', '', 0, 'core'),
    ('visitor', 'about.html', 'About', 'about', '', 0, 'core'),
    ('visitor', 'blog.html', 'Blogs', 'blog', '', 0, 'core'),
    ('visitor', 'Mewad_history_blog.html', 'Mewad history', 'blog', 'gu', 1, 'core'),
    ('visitor', 'vanshavali.html', 'Genealogy', 'gen', 'hi', 1, 'core'),
    ('visitor', 'ananadviharbhavan.html', 'Anand Vihar Bhavan', 'heritage', '', 0, 'core'),
    ('visitor', 'contact.html', 'Contact', 'contact', 'gu', 0, 'core'),
    ('visitor', 'policy-center.html', 'Policy Center', '', '', 0, 'legal'),
    ('visitor', 'privacy-policy.html', 'Privacy Policy', '', '', 0, 'legal'),
    ('visitor', 'termsofuse.html', 'Terms of Use', '', '', 0, 'legal'),
    ('visitor', 'disclaimer.html', 'Disclaimer', '', '', 0, 'legal'),
    ('visitor', 'grievance.html', 'Grievance', '', '', 0, 'legal'),
    ('visitor', 'cookies-policy.html', 'Cookie & Tracking Policy', '', '', 0, 'legal'),
    ('visitor', 'copyright-policy.html', 'Copyright Policy', '', '', 0, 'legal'),
    ('visitor', 'content-editorial-policy.html', 'Content & Editorial Policy', '', '', 0, 'legal'),
    ('visitor', 'data-retention-policy.html', 'Data Retention Policy', '', '', 0, 'legal'),
    ('visitor', 'accessibility-statement.html', 'Accessibility Statement', '', '', 0, 'legal'),
    ('visitor', 'third-party-policy.html', 'Third-Party Services', '', '', 0, 'legal'),
    ('hr', 'HRRindex.html', 'Home', 'home', '', 0, 'core'),
    ('hr', 'resume.html', 'Resume', 'resume', '', 0, 'core'),
    ('hr', 'projects.html', 'Projects', 'projects', '', 0, 'core'),
    ('hr', 'pwriter.html', 'pwriter', 'pwriter', '', 0, 'core'),
    ('hr', 'ghostwriting.html', 'Ghostwriting', 'ghost', '', 0, 'core'),
    ('books', 'BPindex.html', 'Home', 'home', '', 0, 'core'),
    ('books', 'otherlinks.html', 'Publications', 'pub', '', 0, 'core'),
    ('books', 'satyanisodh.html', 'સત્યની શોધ', 'pub', '', 0, 'core'),
    ('books', 'astitva-garima.html', 'અસ્તિત્વ: ધ ગરિમા પ્રોજેક્ટ', 'pub', '', 0, 'core'),
    ('books', 'mahabharat-rajdharma.html', 'राजधर्म (Mahabharat)', 'pub', '', 0, 'core'),
    ('books', 'pushtimarg.html', 'Pushtimarg', 'pushti', '', 0, 'core'),
    ('books', 'pushtimarg-ma-gruh-seva.html', 'પુષ્ટિમાર્ગ માં ગૃહ સેવા', 'pushti', 'gu', 1, 'core'),
    ('books', 'bookreadingpolicy.html', 'Reading policy', 'policy', '', 0, 'legal'),
]
PAGES = []
for portal, f, short, key, lang, prot, grp in P:
    rel = f"{PORTALS[portal]['dir']}/{f}"
    PAGES.append(dict(sect=SECT.get(rel, ''), portal=portal, file=f, rel=rel, short=short, key=key, lang=lang, protect=bool(prot), group=grp, **meta[rel]))
BYREL = {p['rel']: p for p in PAGES}

LEGAL = [('Privacy Policy', 'Visitor/privacy-policy.html'), ('Terms of Use', 'Visitor/termsofuse.html'), ('Disclaimer', 'Visitor/disclaimer.html'),
         ('Grievance', 'Visitor/grievance.html'), ('Policy Center', 'Visitor/policy-center.html')]
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
       "img-src 'self' data:; connect-src 'self' https://formspree.io; form-action 'self' https://formspree.io; base-uri 'self'; "
       "object-src 'none'; manifest-src 'self'; worker-src 'self'")
FONTS = ('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700'
         '&family=Rasa:wght@400;500;600;700&display=swap')

E = html.escape
CUR = ' aria-current="page"'
IC = {
    'search': '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    'theme': '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
    'menu': '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    'close': '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    'up': '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
}


def rel_to(frm_dir, target):
    """relative URL from a page living in frm_dir ('' = root) to target path (root-relative)."""
    r = os.path.relpath(target, frm_dir or '.').replace(os.sep, '/')
    return r


def rewrite_links(h, frm_dir):
    def sub(m):
        path = m.group(1).lstrip('/')
        tgt = 'index.html' if path in ('', 'index.html') else legacy.get(path, path)
        return 'href="' + rel_to(frm_dir, tgt) + (m.group(2) or '') + '"'
    return re.sub(r'href="https://bhargavsinh\.github\.io/?([^"#]*)(#[^"]*)?"', sub, h)


# ------------------------------------------------------------------ chrome templates
def u(root, path):
    return root + path


def head(title, desc, rel, root, extra_ld=None, og_image='assets/images/social/og-default.webp', robots='index, follow, max-image-preview:large', og_type='website', canonical=None):
    url = canonical or (f'{SITE}/{rel}' if rel != 'index.html' else f'{SITE}/')
    ld = ''.join(f'<script type="application/ld+json">{x.strip()}</script>\n' for x in (extra_ld or []))
    return f'''<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Content-Security-Policy" content="{CSP}">
<meta name="referrer" content="strict-origin-when-cross-origin">
<title>{E(title)}</title>
<meta name="description" content="{E(desc)}">
<meta name="author" content="Bhargavsinh Sisodiya">
<meta name="robots" content="{robots}">
<meta name="theme-color" content="#080808">
<meta name="color-scheme" content="dark light">
<link rel="canonical" href="{url}">
<meta property="og:site_name" content="{NAME}">
<meta property="og:type" content="{og_type}">
<meta property="og:title" content="{E(title)}">
<meta property="og:description" content="{E(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{SITE}/{og_image}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{E(title)}">
<meta name="twitter:description" content="{E(desc)}">
<meta name="twitter:image" content="{SITE}/{og_image}">
<link rel="manifest" href="{root}manifest.json">
<link rel="icon" type="image/png" href="{root}assets/images/brand/brand-mark-192.png">
<link rel="apple-touch-icon" href="{root}assets/images/brand/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{root}assets/css/site.css?v={VERSION}">
<link rel="stylesheet" href="{FONTS}" media="print" data-fonts>
<noscript><link rel="stylesheet" href="{FONTS}"></noscript>
<script src="{root}assets/js/theme.js?v={VERSION}"></script>
{ld}'''


def brand(root):
    return (f'<a class="brand" href="{root}index.html" aria-label="{NAME} — home">'
            f'<img src="{root}assets/images/brand/brand-mark-64.webp" srcset="{root}assets/images/brand/brand-mark-64.webp 1x, {root}assets/images/brand/brand-mark-128.webp 2x" alt="" width="34" height="34">'
            f'<span>BHARGAV<b>SINH</b></span></a>')


def bar(root, sect='', portal=None, key='', current=''):
    gl = ''.join(f'<a href="{root}{h}"{CUR if h == current else (" class=\"on\"" if k == sect else "")}>{E(l)}</a>' for l, h, k in GLOBAL)
    sub = ''
    drawer_portal = ''
    if portal:
        pd = PORTALS[portal]
        pl = ''.join(f'<a href="{h}"{CUR if k == key else ""}>{E(l)}</a>' for l, h, k in pd['nav'])
        sub = (f'<div class="subbar"><div class="subbar-in"><a class="badge" href="{pd["home"]}">{E(pd["label"])} portal</a>'
               f'<nav aria-label="{E(pd["label"])} portal">{pl}</nav><a class="switch" href="{root}index.html#portals">All portals</a></div></div>')
        drawer_portal = f'<h5>{E(pd["label"])} portal</h5><nav aria-label="{E(pd["label"])} portal (mobile)">{pl}</nav>'
    others = ''.join(f'<a href="{root}{o["dir"]}/{o["home"]}">{E(o["label"])}</a>' for k, o in PORTALS.items() if k != portal)
    legal = ''.join(f'<a href="{root}{h}">{E(l)}</a>' for l, h in LEGAL)
    return f'''<div class="progress" id="progress" aria-hidden="true"><i></i></div>
<a class="skip" href="#main">Skip to content</a>
<header class="bar" id="top">
  <div class="bar-in">
    {brand(root)}
    <nav class="nav" aria-label="Primary">{gl}</nav>
    <div class="bar-tools">
      <button class="ib" type="button" data-search aria-label="Search the site (press /)">{IC['search']}</button>
      <button class="ib" type="button" id="theme-btn" aria-label="Switch theme" aria-pressed="false">{IC['theme']}</button>
      <button class="ib menu-btn" type="button" id="menu-btn" aria-label="Open menu" aria-expanded="false" aria-controls="drawer">{IC['menu']}</button>
    </div>
  </div>
  {sub}
</header>
<div class="drawer" id="drawer" aria-hidden="true" role="dialog" aria-modal="true" aria-label="Menu">
  <div class="drawer-panel">
    <div class="drawer-top"><strong>Menu</strong><button class="ib" type="button" id="drawer-close" aria-label="Close menu">{IC['close']}</button></div>
    <nav aria-label="Primary (mobile)">{gl}</nav>
    {drawer_portal}
    <h5>Portals</h5>
    <nav aria-label="Portals">{others}<a href="{root}index.html#portals">All portals</a></nav>
    <h5>Legal</h5>
    <nav aria-label="Legal">{legal}</nav>
  </div>
</div>
'''


def overlays(root):
    return f'''<div class="tools" id="tools">
  <button class="ib" type="button" id="fs-up" aria-label="Increase text size">A+</button>
  <button class="ib" type="button" id="fs-down" aria-label="Decrease text size">A−</button>
  <button class="ib" type="button" id="to-top" aria-label="Back to top">{IC['up']}</button>
</div>
<div class="toast" id="toast" role="status" aria-live="polite"><span>A new version is available.</span><button class="btn primary" type="button">Update</button></div>
<div class="search" id="search" role="dialog" aria-modal="true" aria-label="Search" aria-hidden="true">
  <div class="search-box">
    <input id="search-input" type="search" placeholder="Search pages — about, genealogy, સત્યની શોધ…" autocomplete="off" aria-label="Search the site">
    <div class="search-res" id="search-res"></div>
    <div class="search-hint"><span>↑↓ to move</span><span>Enter to open</span><span>Esc to close</span></div>
  </div>
</div>
'''


def footer(root, portal=None):
    gl = ''.join(f'<a href="{root}{h}">{E(l)}</a>' for l, h, k in GLOBAL)
    ports = ''.join(f'<a href="{root}{o["dir"]}/{o["home"]}">{E(o["label"])}</a>' for o in PORTALS.values())
    legal = ''.join(f'<a href="{root}{h}">{E(l)}</a>' for l, h in LEGAL)
    return f'''<footer class="foot">
  <div class="foot-in">
    <div>{brand(root)}<p>{TAGLINE}</p></div>
    <div><h4>Explore</h4>{gl}</div>
    <div><h4>Portals</h4>{ports}</div>
    <div><h4>Legal</h4>{legal}</div>
    <div><h4>Site</h4><a href="{root}sitemap.html">Sitemap</a><a href="{root}changelog.html">Changelog</a><button type="button" class="linkbtn" data-search>Search</button></div>
  </div>
  <div class="foot-base"><span>© <span class="js-year">2026</span> {NAME}</span><span>V{VERSION}</span></div>
</footer>
''' + overlays(root)


def crumbs(page, root):
    pd = PORTALS[page['portal']]
    items = [f'<a href="{root}index.html">Home</a>', f'<a href="{pd["home"]}">{E(pd["label"])}</a>']
    if page['file'] != pd['home']:
        items.append(f'<span aria-current="page">{E(page["short"])}</span>')
    sep = ' <span aria-hidden="true">›</span> '
    return f'<nav class="crumbs" aria-label="Breadcrumb" data-ui>{sep.join(items)}</nav>'


def doc(title, desc, rel, root, body_cls, bar_html, main_html, foot_html, ld=None, robots='index, follow, max-image-preview:large', canonical=None, prot='', extra_attr=''):
    return f'''<!doctype html>
<html lang="en" data-root="{root}">
<head>
{head(title, desc, rel, root, ld, robots=robots, canonical=canonical)}</head>
<body class="{body_cls}"{prot}>
{bar_html}{main_html}
{foot_html}<script src="{root}assets/js/site.js?v={VERSION}" defer></script>
</body>
</html>
'''


def page_html(page, body):
    root = '../'
    lang = f' lang="{page["lang"]}"' if page['lang'] else ''
    prot = ' data-protect' if page['protect'] else ''
    if '<h1' not in body:
        body = f'<h1 class="vh">{html.escape(page["title"])}</h1>\n' + body
    main = f'<main class="page" id="main"{lang}>\n{crumbs(page, root)}\n{body}\n</main>'
    return doc(page['title'], page['description'], page['rel'], root, f'portal-{page["portal"]}', bar(root, page['sect'], page['portal'], page['key'], current=page['rel']),
               main, footer(root, page['portal']), page['ld'], prot=prot)



# ------------------------------------------------------------------ fragment post-processing
def load_fragment(rel):
    s = open(os.path.join(HERE, 'content', rel.replace('/', '__')), encoding='utf8').read()
    s = re.sub(r'^\s*(<br\s*/?>\s*)+', '', s).strip()
    s = rewrite_links(s, PORTALS[BYREL[rel]['portal']]['dir'])
    s = s.replace('../a1logo.png', '../assets/images/heritage/anand-vihar-logo.webp')
    return s


def tweak(rel, s):
    soup = BeautifulSoup(s, 'lxml')
    body = soup.body

    def add(tag_html, where='start'):
        n = BeautifulSoup(tag_html, 'lxml').body.contents[0]
        if where == 'start': body.insert(0, n)
        else: body.append(n)
        return n

    if rel == 'Visitor/vanshavali.html':
        gb = body.select_one('.gen-body')
        title = gb.select_one('.gen-title')
        raw = []
        for node in list(gb.children):
            if node is title: continue
            if isinstance(node, str): raw.append(str(node)); node.extract()
        lines = [ln.strip() for ln in ''.join(raw).splitlines() if ln.strip()]
        started = False
        for ln in lines:
            m = re.match(r'^(\d+)\.\s+(.*)$', ln)
            p = soup.new_tag('p')
            if m:
                started = True
                p['class'] = ['gl', 'n']; p['data-n'] = m.group(1)
                b = soup.new_tag('b'); b.string = m.group(1) + '.'; p.append(b); p.append(' ' + m.group(2))
            else:
                p['class'] = ['gl'] + ([] if started else ['meta']); p.string = ln
            gb.append(p)
        wrap = soup.new_tag('div'); wrap['class'] = ['gen-wrap']
        tools = BeautifulSoup('<div class="gen-tools" data-ui><label class="vh" for="gen-q">Search the genealogy</label>'
                              '<input id="gen-q" type="search" placeholder="Search a name, or type an entry number…" autocomplete="off">'
                              '<span class="count" id="gen-count" aria-live="polite"></span></div>', 'lxml').body.contents[0]
        # move children of the first main wrapper into wrap
        for n in list(body.contents): wrap.append(n.extract())
        banner = BeautifulSoup('<img class="hero-media" data-ui src="../assets/images/visitor/visitor-vanshavali-hero.webp" alt="" width="1600" height="600" decoding="async">', 'lxml').body.contents[0]
        body.append(banner); body.append(wrap)
        wrap.insert(1, tools)
    elif rel == 'Visitor/Mewad_history_blog.html':
        body.insert(0, BeautifulSoup('<img class="hero-media" data-ui src="../assets/images/visitor/visitor-mewad-hero.webp" alt="" width="1600" height="600" decoding="async">', 'lxml').body.contents[0])
    elif rel == 'HR-Recruiter/resume.html':
        first = body.select_one('.box > .tc') or body.select_one('.tc')
        if first:
            first.insert(0, BeautifulSoup('<img data-ui src="../assets/images/hr/hr-portrait-square.webp" alt="Portrait of Bhargavsinh Sisodiya" width="800" height="800" decoding="async" class="portrait">', 'lxml').body.contents[0])
            first.append(BeautifulSoup('<p data-ui class="actions"><button type="button" class="btn ghost" data-print>Print / save as PDF</button></p>', 'lxml').body.contents[0])
    elif rel == 'HR-Recruiter/pwriter.html':
        wrap = soup.new_tag('div'); wrap['class'] = ['tool-grid']
        for n in list(body.contents): wrap.append(n.extract())
        h = BeautifulSoup('<header class="hero" data-ui><span class="eyebrow">AI tool</span><h1>pwriter</h1><p class="lead">Advanced Deep AI Prompt Architect.</p></header>', 'lxml').body.contents[0]
        body.append(h); body.append(wrap)
        for btn in body.select('button[data-action]'):
            a = btn['data-action']
            btn['class'] = ['btn', 'primary'] if a == 'generateDeepPrompt' else ['btn', 'ghost']
            btn['type'] = 'button'
        g = body.select_one('button[data-action=generateDeepPrompt]')
        if g: g['style'] = None; del g['style']
        st = body.select_one('#status-text')
        if st: st['aria-live'] = 'polite'
    elif rel == 'Visitor/contact.html':
        for sel, ac in (('input[name=name]', 'name'), ('input[name=email]', 'email'), ('input[name=phone]', 'tel')):
            e = body.select_one(sel)
            if e: e['autocomplete'] = ac
        for row in body.select('.flex'):
            kids = [k for k in row.children if not (isinstance(k, str) and not k.strip())]
            if kids and getattr(kids[0], 'get', None) and 'box' in (kids[0].get('class') or []) and 'jc' in (kids[0].get('class') or []) and len(kids) > 1:
                w = soup.new_tag('div')
                for k in kids[1:]: w.append(k.extract())
                row.append(w)
    elif rel == 'Book-Publications-Reader/otherlinks.html':
        pass
    for a in body.select('a[href^="http"]'):
        a['rel'] = 'noopener noreferrer'; a['target'] = '_blank'
    for a in body.select('a.card-link'):
        card = a.find_parent(class_='card'); h = card.find(['h2', 'h3']) if card else None
        if h: a['aria-label'] = a.get_text(' ', strip=True) + ' — ' + h.get_text(' ', strip=True)
    out = body.decode_contents()
    return out


def build_pages():
    for p in PAGES:
        frag = tweak(p['rel'], load_fragment(p['rel']))
        path = os.path.join(OUT, p['rel'])
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # skeleton text for search index
        soup = BeautifulSoup(frag, 'lxml')
        heads = [h.get_text(' ', strip=True) for h in soup.find_all(['h1', 'h2', 'h3'])]
        p['heads'] = ' · '.join(dict.fromkeys(heads))[:700]
        open(path, 'w', encoding='utf8').write(page_html(p, frag))


# ------------------------------------------------------------------ root + hub pages
def L(root, href):
    return href if href.startswith(('http', 'mailto:', '#')) else root + href


def simple_page(rel, title, desc, inner, root='', robots='index, follow', cls=''):
    main = f'<main class="page{cls}" id="main">\n{inner}\n</main>'
    return doc(title, desc, rel, root, 'plain', bar(root, current=rel), main, footer(root), robots=robots)


def sec_head(eyebrow, title, hid, href=None, label=None, root=''):
    more = f'<a class="more" href="{L(root, href)}">{E(label)} <span aria-hidden="true">→</span></a>' if href else ''
    return f'<div class="sec-head"><div><p class="eyebrow">{E(eyebrow)}</p><h2 id="{hid}">{E(title)}</h2></div>{more}</div>'


def project_card(p, root):
    facts = ''.join(f'<div><dt>{k}</dt><dd>{E(v)}</dd></div>' for k, v in (('Category', p.get('category')), ('Stack', ', '.join(p['stack']) if p.get('stack') else None), ('Status', p.get('status'))) if v)
    links = ''.join(f'<a href="{L(root, l["href"])}">{E(l["label"])}</a>' for l in p.get('links', []))
    if p.get('live'): links += f'<a href="{L(root, p["live"])}">Live Demo</a>'
    if p.get('source'): links += f'<a href="{L(root, p["source"])}">Source Code</a>'
    return (f'<article class="card"><h3>{E(p["name"])}</h3><p>{E(p["description"])}</p>'
            f'{"<dl class=facts>" + facts + "</dl>" if facts else ""}'
            f'<div class="links">{links}<a href="{L(root, p["more"])}" aria-label="Read about {E(p["name"])} in About">Read in About</a></div></article>')


def pub_card(p, root):
    cover = (f'<img class="pcover" src="{root}{p["cover"]}" alt="Cover of {E(p["title"])}" width="200" height="300" loading="lazy" decoding="async">' if p.get('cover') else '')
    cls = 'ok' if p['status'] == 'Published' else ''
    plat = f'<a href="{p["platform_href"]}">{E(p["platform"])}</a>' if p.get('platform') else ''
    meta = (f'<div><dt>Author</dt><dd>{E(p["author"])}</dd></div><div><dt>Language</dt><dd>{E(p["language"])}</dd></div>'
            f'<div><dt>Category</dt><dd>{E(p["category"])}</dd></div>' + (f'<div><dt>Date</dt><dd>{E(p["date"])}</dd></div>' if p.get('date') else ''))
    return (f'<article class="card pub" data-lang="{E(p["language"])}" data-status="{E(p["status"])}" data-text="{E((p["title"] + " " + p["subtitle"] + " " + p["category"]).lower())}">'
            f'{cover}<div class="pub-body"><span class="chip {cls}">{E(p["status"])}</span><h3>{E(p["title"])}</h3><p class="muted">{E(p["subtitle"])}</p><dl class="facts">{meta}</dl>'
            f'<div class="links"><a class="btn ghost" href="{root}{p["href"]}" aria-label="{E(p["cta"])} — {E(p["title"])}">{E(p["cta"])}</a>{plat}</div></div></article>')


def research_card(r, root):
    meta = ''.join(f'<div><dt>{k}</dt><dd>{E(v)}</dd></div>' for k, v in (('Date', r.get('date')), ('Status', r.get('status')), ('Source', r.get('source'))) if v)
    return (f'<article class="card"><p class="eyebrow">{E(r["kind"])}</p><h3>{E(r["title"])}</h3><p>{E(r["desc"])}</p>'
            f'{"<dl class=facts>" + meta + "</dl>" if meta else ""}'
            f'<a class="card-link" href="{L(root, r["href"])}" aria-label="{E(r["cta"])} — {E(r["title"])}">{E(r["cta"])}</a></article>')


def contact_links(root, cls='clist'):
    out = ''.join(f'<li><span>{E(l["label"])}</span><a href="{l["href"]}">{E(l["text"])}</a></li>' for l in DATA['profile']['links'])
    return f'<ul class="{cls}">{out}</ul>'


def build_home():
    pr, pj, pb, rs = DATA['profile'], DATA['projects'], DATA['publications'], DATA['research']['items']
    root = ''
    feat = ''.join(project_card(p, root) for p in pj['items'] if p.get('featured'))
    books = ''.join(pub_card(p, root) for p in pb['items'] if p['group'] == 'Books')
    res = ''.join(research_card(r, root) for r in rs[:4])
    inst = pr['institution']
    portal_cards = [
        ('Book-Publications-Reader/BPindex.html', 'assets/images/portals/portal-books.webp', 'Book & Publications Reader', 'Published Gujarati works, research essays and reading resources.'),
        ('HR-Recruiter/HRRindex.html', 'assets/images/portals/portal-hr.webp', 'HR Recruiter', 'Skills, projects and writing work at a glance.'),
        ('Visitor/Visitindex.html', 'assets/images/portals/portal-visitor.webp', 'Visitor', 'Personal projects, Gujarati writing, genealogy and heritage.')]
    plis = ''.join(f'<li><a class="portal" href="{h}" data-name="{E(n)}" aria-label="Enter {E(n)} portal"><span class="portal-img"><img src="{i}" alt="" width="136" height="136" loading="lazy" decoding="async"></span><b>{E(n)}</b><span>{E(d)}</span></a></li>' for h, i, n, d in portal_cards)
    main = f'''<main id="main" class="home-main">
<section class="h-hero" aria-labelledby="hero-h">
  <div class="h-hero-text">
    <p class="eyebrow">Digital Portfolio</p>
    <h1 id="hero-h">{E(pr['name'])}</h1>
    <p class="tagline">{TAGLINE}</p>
    <p class="lead">{E(pr['lead'])}</p>
    <div class="actions"><a class="btn primary" href="projects/">Projects</a><a class="btn ghost" href="publications/">Publications</a><a class="btn ghost" href="research/">Research &amp; Heritage</a><a class="btn ghost" href="contact/">Contact</a></div>
  </div>
  <figure class="h-portrait"><img src="assets/images/hr/hr-portrait-480.webp" alt="Portrait of Bhargavsinh Sisodiya" width="480" height="480" fetchpriority="high" decoding="async"></figure>
</section>
<section class="band" aria-labelledby="intro-h">
  {sec_head('01', 'Introduction', 'intro-h', 'about/', 'About', root)}
  <p class="big">{E(pr['summary'])}</p>
  <p class="muted">{E(pr['headline'])}</p>
</section>
<section class="band" aria-labelledby="proj-h">
  {sec_head('02', 'Featured Projects', 'proj-h', 'projects/', 'All projects', root)}
  <div class="grid">{feat}</div>
  <p class="note">{E(pj['note'])}</p>
</section>
<section class="band" aria-labelledby="pub-h">
  {sec_head('03', 'Publications', 'pub-h', 'publications/', 'Digital library', root)}
  <div class="grid pubs">{books}</div>
</section>
<section class="band" aria-labelledby="res-h">
  {sec_head('04', 'Research & Heritage', 'res-h', 'research/', 'All research', root)}
  <div class="grid">{res}</div>
</section>
<section class="band" aria-labelledby="inst-h">
  {sec_head('05', 'Institutional Presence', 'inst-h', inst['href'], 'Anand Vihar Bhavan', root)}
  <div class="inst"><img src="assets/images/heritage/anand-vihar-logo.webp" alt="Anand Vihar Bhavan emblem" width="160" height="160" loading="lazy" decoding="async"><div><h3>{E(inst['title'])}</h3><p class="lead">{E(inst['tag'])}</p><p>{E(inst['text'])}</p></div></div>
</section>
<section class="band" id="portals" aria-labelledby="port-h">
  {sec_head('06', 'Portals', 'port-h')}
  <ul class="portals" role="list">{plis}</ul>
  <p class="resume-link" id="resume-slot" hidden></p>
</section>
<section class="band" aria-labelledby="contact-h">
  {sec_head('07', 'Contact', 'contact-h', 'contact/', 'Contact', root)}
  <p>{E(pr['contact_note'])}</p>
  {contact_links(root)}
</section>
</main>'''
    ld = [json.dumps({'@context': 'https://schema.org', '@type': 'Person', 'name': 'Bhargavsinh Sisodiya', 'url': SITE + '/', 'sameAs': [l['href'] for l in pr['links'] if l['href'].startswith('https://') and 'pushtisahitya' not in l['href']]}, ensure_ascii=False),
          json.dumps({'@context': 'https://schema.org', '@type': 'WebSite', 'name': NAME, 'url': SITE + '/'})]
    return doc('Bhargavsinh Sisodiya | Digital Portfolio, Projects & Publications',
               'Official digital portfolio of Bhargavsinh Sisodiya, documenting technology projects, Gujarati publications, independent research and cultural heritage.',
               'index.html', root, 'home', bar(root, current='index.html'), main, footer(root), ld)


HUBS = {}


def hub(slug, title, desc, h1, lead, inner, sect, extra=''):
    root = '../'
    rel = f'{slug}/index.html'
    head_html = f'<header class="hero hub-hero"><p class="eyebrow" data-ui>{E(sect)}</p><h1>{E(h1)}</h1>{f"<p class=lead>{E(lead)}</p>" if lead else ""}</header>'
    cr = f'<nav class="crumbs" aria-label="Breadcrumb" data-ui><a href="{root}index.html">Home</a> <span aria-hidden="true">›</span> <span aria-current="page">{E(h1)}</span></nav>'
    main = f'<main class="page" id="main">\n{cr}\n{head_html}\n{inner}\n</main>'
    html_ = doc(f'{title} | Bhargavsinh Sisodiya', desc, rel, root, 'hub', bar(root, sect=slug, current=slug + '/'), main, footer(root), canonical=f'{SITE}/{slug}/')
    os.makedirs(os.path.join(OUT, slug), exist_ok=True)
    open(os.path.join(OUT, rel), 'w', encoding='utf8').write(html_)
    HUBS[slug] = dict(title=title, desc=desc, heads=h1)


def build_hubs():
    root = '../'
    pr, pj, pb, rs = DATA['profile'], DATA['projects'], DATA['publications'], DATA['research']['items']
    # About
    cards = ''.join(f'<article class="card"><p class="eyebrow">{E(a["label"])}</p><h3>{E(a["heading"])}</h3><p>{E(a["text"])}</p>'
                    f'<a class="card-link" href="{root}Visitor/about.html#{a["id"]}" aria-label="Read more — {E(a["heading"])}">Read more</a></article>' for a in pr['about'])
    inner = (f'<section class="band flat" aria-label="About sections"><div class="grid">{cards}</div></section>'
             f'<div class="actions"><a class="btn primary" href="{root}Visitor/about.html">Full About page</a><a class="btn ghost" href="{root}HR-Recruiter/resume.html">Resume</a></div>')
    hub('about', 'About', pr['headline'], 'About Bhargavsinh Sisodiya', pr['headline'], inner, 'Profile')
    # Projects
    cards = ''.join(project_card(p, root) for p in pj['items'])
    extra = ''.join(f'<article class="card"><p class="eyebrow">{E(x["kind"])}</p><h3>{E(x["title"])}</h3><p>{E(x["desc"])}</p><a class="card-link" href="{root}{x["href"]}" aria-label="Open {E(x["title"])}">Open</a></article>' for x in (pj['work'], pj['tool']))
    inner = (f'<section class="band flat" aria-label="Independent projects"><div class="grid">{cards}</div><p class="note">{E(pj["note"])}</p></section>'
             f'<section class="band" aria-labelledby="more-h">{sec_head("HR Recruiter portal", "Work & tools", "more-h")}<div class="grid">{extra}</div></section>')
    hub('projects', 'Projects', 'Independent projects and experiments by Bhargavsinh Sisodiya: portfolio, SDSP, BharBlock, digital genealogy and literary publishing.', 'Projects', pj['work']['desc'], inner, 'Technology')
    # Publications
    langs = sorted({p['language'] for p in pb['items']})
    stats = sorted({p['status'] for p in pb['items']})
    opts = ''.join(f'<option value="{E(l)}">{E(l)}</option>' for l in langs)
    sopts = ''.join(f'<option value="{E(s_)}">{E(s_)}</option>' for s_ in stats)
    filt = (f'<form class="filter" role="search" aria-label="Filter publications" onsubmit="return false" data-ui>'
            f'<label class="vh" for="pub-q">Search publications</label><input id="pub-q" type="search" placeholder="Search title or category…" autocomplete="off">'
            f'<label class="vh" for="pub-lang">Language</label><select id="pub-lang"><option value="">All languages</option>{opts}</select>'
            f'<label class="vh" for="pub-status">Status</label><select id="pub-status"><option value="">All statuses</option>{sopts}</select>'
            f'<span class="count" id="pub-count" aria-live="polite"></span></form>')
    groups = ''
    for g in ('Books', 'Other Publications'):
        groups += f'<section class="band flat" aria-label="{g}" data-group><h2 class="mini">{g}</h2><div class="grid pubs">' + ''.join(pub_card(p, root) for p in pb['items'] if p['group'] == g) + '</div></section>'
    inner = filt + groups + f'<p class="note" data-ui-keep>{E(pb["note"])}</p>'
    hub('publications', 'Publications', 'Gujarati and Hindi books, articles and historical records published by Bhargavsinh Sisodiya — a digital library with search.', 'Publications', 'Books, articles and historical records published by BHARGAVSINH SISODIYA', inner, 'Digital Library')
    # Research
    cards = ''.join(research_card(r, root) for r in rs)
    hub('research', 'Research & Heritage', 'Genealogy, Mewad history, Pushtimarg literature and digital archives by Bhargavsinh Sisodiya.', 'Research & Heritage', None, f'<section class="band flat" aria-label="Research and heritage"><div class="grid">{cards}</div></section>', 'Archive')
    # Contact
    inner = (f'<section class="band flat"><p class="big">{E(pr["contact_note"])}</p>{contact_links(root, "clist big-list")}'
             f'<div class="actions"><a class="btn primary" href="{root}Visitor/contact.html">Contact form</a></div></section>')
    hub('contact', 'Contact', 'Official email and public profiles of Bhargavsinh Sisodiya.', 'Contact', None, inner, 'Official profiles')



def md_to_html(md):
    out, in_ul = [], False
    for ln in md.splitlines():
        ln = ln.rstrip()
        if ln.startswith('- '):
            if not in_ul: out.append('<ul>'); in_ul = True
            out.append('<li>' + inline(ln[2:]) + '</li>'); continue
        if in_ul: out.append('</ul>'); in_ul = False
        if ln.startswith('### '): out.append('<h3>' + inline(ln[4:]) + '</h3>')
        elif ln.startswith('## '): out.append('</div><div class="box">' if out else '<div class="box">'); out.append('<h2>' + inline(ln[3:]) + '</h2>')
        elif ln.strip(): out.append('<p>' + inline(ln) + '</p>')
    if in_ul: out.append('</ul>')
    return '\n'.join(out)


def inline(s):
    s = E(s)
    s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
    s = re.sub(r'`(.+?)`', r'<code>\1</code>', s)
    return s


def build_changelog():
    new = f'''## V{VERSION} — {TODAY}
### Blueprint V1.1 implementation (Royal Editorial × Digital Institution)
- New design system: obsidian / ivory / royal gold, serif headings, accessible-gold text on light surfaces
- Typography: Rasa for Gujarati, Noto Sans Devanagari for Hindi, system sans-serif for English body, editorial serif for English headings; fonts load without blocking render
- New information architecture: Home, About, Projects, Publications, Research & Heritage, Contact (hub pages), with the three portals preserved at their existing URLs
- Home rebuilt: identity, introduction, featured projects, publications, research & heritage, institutional presence, portals, contact
- Hub pages are generated from data/profile.json, projects.json, publications.json and research.json — every string in them is verbatim existing site text
- Publications: searchable and filterable digital library
- Global primary navigation plus a portal sub-bar on every portal page; breadcrumbs
- Accessibility: contrast-checked palette, labelled landmarks, descriptive link names, visible focus, reduced-motion support
- Performance: no render-blocking font stylesheet, 64 px and 128 px brand-mark variants with srcset, explicit image dimensions, versioned asset URLs
- Security: strict meta CSP (no frame-ancestors), no inline scripts or styles, rel="noopener noreferrer" on every external link, security.txt
- Sitemap lists canonical URLs only, with real lastmod values
- Service worker: network-first pages, update prompt, stale cache purge on activate
- Fixed: pwriter output used literal "\\n" and mis-counted words; pushtidoctor.html redirect target
- All earlier URLs keep working (legacy root redirects retained)

'''
    old = open(os.path.join(HERE, 'changelog_old.md'), encoding='utf8').read().replace('# Changelog', '').strip()
    parts = md_to_html(new + old).replace('</div><div class="box">', '</div><div class="box">')
    body = '<header class="hero"><p class="eyebrow">Release notes</p><h1>Changelog</h1></header>\n<div class="stack">' + parts + '</div></div>'
    body = body.replace('<div class="stack"></div><div class="box">', '<div class="stack"><div class="box">')
    open(os.path.join(OUT, 'changelog.html'), 'w', encoding='utf8').write(
        simple_page('changelog.html', f'Changelog | {NAME}', 'Release history of the Bhargavsinh Sisodiya digital portfolio.', body))
    return new


def build_sitemap_html():
    groups = []
    gl = ''.join(f'<li><a href="{h}">{E(l)}</a></li>' for l, h, k in GLOBAL)
    groups.append(f'<section class="box"><h2>Main</h2><ul>{gl}</ul></section>')
    for key, pd in PORTALS.items():
        li = ''.join(f'<li><a href="{p["rel"]}">{E(p["title"].split(" | ")[0])}</a></li>' for p in PAGES if p['portal'] == key and p['group'] == 'core')
        groups.append(f'<section class="box"><h2>{E(pd["label"])} portal</h2><ul>{li}</ul></section>')
    leg = ''.join(f'<li><a href="{p["rel"]}">{E(p["title"].split(" | ")[0])}</a></li>' for p in PAGES if p['group'] == 'legal')
    groups.append(f'<section class="box"><h2>Policies &amp; legal</h2><ul>{leg}</ul></section>')
    groups.append('<section class="box"><h2>Site</h2><ul><li><a href="changelog.html">Changelog</a></li></ul></section>')
    body = '<header class="hero"><p class="eyebrow">Every page</p><h1>Sitemap</h1></header>\n<div class="grid">' + ''.join(groups) + '</div>'
    open(os.path.join(OUT, 'sitemap.html'), 'w', encoding='utf8').write(simple_page('sitemap.html', f'Sitemap | {NAME}', 'All pages of the Bhargavsinh Sisodiya digital portfolio.', body))


def build_states():
    body = '<div class="state"><h1>Page not found</h1><p class="muted">The page you requested does not exist or has moved.</p><p class="actions"><a class="btn primary" href="/index.html">Home</a><a class="btn ghost" href="/sitemap.html">Sitemap</a></p></div>'
    open(os.path.join(OUT, '404.html'), 'w', encoding='utf8').write(simple_page('404.html', f'Page not found | {NAME}', 'The page you requested does not exist or has moved.', body, root='/', robots='noindex'))
    body = '<div class="state"><h1>You are offline</h1><p class="muted">This page is not available offline. Reconnect and try again.</p><p class="actions"><a class="btn primary" href="/index.html">Back to home</a></p></div>'
    open(os.path.join(OUT, 'offline.html'), 'w', encoding='utf8').write(simple_page('offline.html', f'Offline | {NAME}', 'You are offline.', body, root='/', robots='noindex'))


def build_redirects():
    for old, new in legacy.items():
        if not old.endswith('.html'): continue
        t = new
        open(os.path.join(OUT, old), 'w', encoding='utf8').write(
            f'<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><title>Redirecting…</title>'
            f'<meta name="robots" content="noindex"><meta http-equiv="refresh" content="0; url={t}">'
            f'<link rel="canonical" href="{SITE}/{t}"></head>'
            f'<body><p>Redirecting to <a href="{t}">{t}</a>…</p></body></html>\n')


KW = {'vanshavali': 'genealogy family tree lineage वंशावली વંશાવલી sisodiya suryavansh', 'about': 'about biography bhargavsinh sisodiya profile', 'blog': 'blog articles essays', 'contact': 'contact email appointment form whatsapp',
      'resume': 'resume cv career professional skills', 'ghostwriting': 'ghostwriting writing services rates', 'pwriter': 'prompt ai tool', 'satyanisodh': 'satyani shodh truth book સત્યની શોધ',
      'Mewad history blog': 'mewad history mewar sisodiya', 'ananadviharbhavan': 'anand vihar bhavan heritage residence', 'otherlinks': 'publications catalogue books links'}


def build_data():
    idx = []
    for p in PAGES:
        label = 'Policy' if p['group'] == 'legal' and p['portal'] == 'visitor' else PORTALS[p['portal']]['label']
        idx.append(dict(t=p['title'].split(' | ')[0], u=p['rel'], p=label, d=p['description'], h=p['heads'], k=(p['file'].replace('.html', '').replace('_', ' ').replace('-', ' ') + ' ' + KW.get(p['file'].replace('.html', ''), KW.get(p['file'].replace('.html', '').replace('_', ' ').replace('-', ' '), '')))))
    idx.insert(0, dict(t='Who’s Visiting? — portal selector', u='index.html', p='Home', d='Choose your portal.', h='', k='home portals'))
    idx.append(dict(t='Sitemap', u='sitemap.html', p='Site', d='All pages.', h='', k='sitemap map pages'))
    idx.append(dict(t='Changelog', u='changelog.html', p='Site', d='Release history.', h='', k='changelog releases version'))
    json.dump(idx, open(os.path.join(OUT, 'assets', 'search-index.json'), 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))

    for slug, h in HUBS.items():
        idx.append(dict(t=h['title'], u=slug + '/', p='Main', d=h['desc'], h=h['heads'], k=slug))
    json.dump(idx, open(os.path.join(OUT, 'assets', 'search-index.json'), 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))

    urls = [('', TODAY)] + [(f'{sl}/', TODAY) for sl in HUBS] + [(p['rel'], LASTMOD.get(p['rel'], TODAY)) for p in PAGES] + [('sitemap.html', TODAY), ('changelog.html', TODAY)]
    def prio(u):
        if u == '': return '1.0', 'weekly'
        if u in [f'{sl}/' for sl in HUBS] or u.endswith(('Visitindex.html', 'HRRindex.html', 'BPindex.html')): return '0.9', 'weekly'
        if u in BYREL and BYREL[u]['group'] == 'legal': return '0.3', 'yearly'
        return '0.7', 'monthly'
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u_, lm in urls:
        pr, cf = prio(u_)
        xml.append(f'  <url><loc>{SITE}/{u_}</loc><lastmod>{lm}</lastmod><changefreq>{cf}</changefreq><priority>{pr}</priority></url>')
    xml.append('</urlset>')
    open(os.path.join(OUT, 'sitemap.xml'), 'w', encoding='utf8').write('\n'.join(xml) + '\n')
    sec = ('Contact: mailto:bhargavsinh.bca@gmail.com\nExpires: 2027-11-06T00:00:00.000Z\nPreferred-Languages: en, gu, hi\n'
           f'Canonical: {SITE}/.well-known/security.txt\n')
    os.makedirs(os.path.join(OUT, '.well-known'), exist_ok=True)
    open(os.path.join(OUT, 'security.txt'), 'w', encoding='utf8').write(sec)
    open(os.path.join(OUT, '.well-known', 'security.txt'), 'w', encoding='utf8').write(sec)
    open(os.path.join(OUT, 'robots.txt'), 'w', encoding='utf8').write(
        'User-agent: *\nAllow: /\n\nUser-agent: GPTBot\nDisallow: /\n\nUser-agent: CCBot\nDisallow: /\n\nUser-agent: Google-Extended\nDisallow: /\n\n'
        f'Sitemap: {SITE}/sitemap.xml\n')

    manifest = {
        'id': '/', 'name': f'{NAME} — Digital Universe', 'short_name': 'BHARGAVSINH',
        'description': 'Three-portal portfolio: Books & Publications, HR Recruiter, and Visitor.',
        'start_url': '/', 'scope': '/', 'display': 'standalone', 'orientation': 'any', 'lang': 'en',
        'background_color': '#080808', 'theme_color': '#080808', 'categories': ['portfolio', 'books', 'education'],
        'icons': [
            {'src': 'assets/images/brand/brand-mark-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
            {'src': 'assets/images/brand/brand-mark-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
            {'src': 'assets/images/brand/maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}],
        'shortcuts': [
            {'name': 'Books & Publications', 'url': 'Book-Publications-Reader/BPindex.html'},
            {'name': 'HR Recruiter', 'url': 'HR-Recruiter/HRRindex.html'},
            {'name': 'Visitor', 'url': 'Visitor/Visitindex.html'}]}
    json.dump(manifest, open(os.path.join(OUT, 'manifest.json'), 'w', encoding='utf8'), indent=2, ensure_ascii=False)

    precache = ['/', '/index.html', '/offline.html', '/404.html', '/sitemap.html', '/changelog.html', '/manifest.json'] + [f'/{sl}/' for sl in HUBS] + ['/assets/css/site.css?v=' + VERSION,
                '/assets/js/site.js?v=' + VERSION, '/assets/js/theme.js?v=' + VERSION, '/assets/search-index.json', '/assets/images/brand/brand-mark.webp',
                '/assets/images/brand/brand-mark-192.png', '/assets/images/portals/portal-books.webp', '/assets/images/portals/portal-hr.webp', '/assets/images/portals/portal-visitor.webp'] + ['/' + p['rel'] for p in PAGES]
    sw = open(os.path.join(HERE, 'sw.template.js'), encoding='utf8').read().replace('__VERSION__', VERSION).replace('__PRECACHE__', json.dumps(precache, indent=2))
    open(os.path.join(OUT, 'sw.js'), 'w', encoding='utf8').write(sw)


def copy_assets():
    src = os.path.join(HERE, 'assets')
    for r, _, fs in os.walk(src):
        for f in fs:
            s = os.path.join(r, f)
            d = os.path.join(OUT, 'assets', os.path.relpath(s, src))
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.copy2(s, d)


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    copy_assets()
    shutil.copytree(os.path.join(HERE, 'data'), os.path.join(OUT, 'data'), dirs_exist_ok=True)
    build_pages()
    open(os.path.join(OUT, 'index.html'), 'w', encoding='utf8').write(build_home())
    build_hubs()
    build_changelog(); build_sitemap_html(); build_states(); build_redirects(); build_data()
    open(os.path.join(OUT, '.nojekyll'), 'w').close()
    print('built', len(PAGES), 'content pages →', OUT)
