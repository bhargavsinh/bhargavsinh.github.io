"""QA: (1) text fidelity vs reference, (2) internal link/asset integrity. Usage: check.py <site_dir> <ref_dir>"""
import sys, os, re, json, difflib
from bs4 import BeautifulSoup
site, ref = sys.argv[1], sys.argv[2]
def words(node):
    for t in node.select('[data-ui],script,style,nav.crumbs,h1.vh'): t.decompose()
    t = node.get_text(' ')
    t = t.replace('•',' ')
    return re.sub(r'\s+',' ',t).strip()
bad = 0
for d in ('Visitor','HR-Recruiter','Book-Publications-Reader'):
    for f in sorted(os.listdir(os.path.join(ref,d))):
        if not f.endswith('.html'): continue
        a = BeautifulSoup(open(os.path.join(ref,d,f),encoding='utf8').read(),'lxml').find('main')
        b = BeautifulSoup(open(os.path.join(site,d,f),encoding='utf8').read(),'lxml').find('main')
        ta, tb = words(a), words(b)
        # tolerate the original's duplicated (table+cards) markup being kept: compare as token sequences
        if ta == tb: continue
        sm = difflib.SequenceMatcher(None, ta.split(' '), tb.split(' '), autojunk=False)
        diffs = [(op, ' '.join(ta.split(' ')[i1:i2])[:90], ' '.join(tb.split(' ')[j1:j2])[:90]) for op,i1,i2,j1,j2 in sm.get_opcodes() if op!='equal']
        bad += 1
        print(f'TEXT DIFF {d}/{f}: {len(diffs)} change(s)')
        for x in diffs[:6]: print('    ', x)
print('text-diff pages:', bad)
# links
missing = []
for r,_,fs in os.walk(site):
    if '_build' in r: continue
    for f in fs:
        if not f.endswith('.html'): continue
        p = os.path.join(r,f)
        s = BeautifulSoup(open(p,encoding='utf8').read(),'lxml')
        for t in s.find_all(['a','link','img','script']):
            u = t.get('href') or t.get('src')
            if not u or re.match(r'(https?:|mailto:|tel:|#|data:|javascript:)',u): continue
            u = u.split('#')[0].split('?')[0]
            if not u: continue
            tgt = os.path.normpath(os.path.join(site, u.lstrip('/')) if u.startswith('/') else os.path.join(r,u))
            if not os.path.exists(tgt): missing.append((os.path.relpath(p,site),u))
print('missing internal refs:', len(missing))
for m in missing[:30]: print('   ',m)
